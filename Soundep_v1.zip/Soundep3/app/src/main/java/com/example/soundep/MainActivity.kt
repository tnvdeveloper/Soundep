package com.example.soundep

import android.content.Context
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.soundep.ui.theme.SoundepTheme
import androidx.appcompat.app.AppCompatActivity
import android.widget.ListView
import android.widget.TextView
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SoundepTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Greeting("Android")
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    SoundepTheme {
        Greeting("Android")
    }
}

class MusicPlayerActivity : AppCompatActivity() {
    private lateinit var songList: ListView
    private lateinit var songAdapter: SongAdapter
    private var songs = mutableListOf<Song>()
    private lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        songList = findViewById<ListView>(R.id.song_list)
        songAdapter = SongAdapter(this, songs)
        songList.adapter = songAdapter

        // Получаем список песен с устройства
        val musicFiles = getMusicFiles()
        songs.addAll(musicFiles)

        // Отображаем список песен
        songAdapter.notifyDataSetChanged()

        // Создаем MediaPlayer
        mediaPlayer = MediaPlayer()
    }

    // Функция для проигрыша музыки
    fun playMusic(song: Song) {
        // Создаем MediaPlayer
        val mediaPlayer = MediaPlayer()
        mediaPlayer.setOnPreparedListener {
            // Код для проигрыша музыки
            mediaPlayer.start()
        }
        mediaPlayer.setOnCompletionListener {
            // Код для выполнения после completion
        }
        mediaPlayer.setVolume(1.0f, 1.0f)
        mediaPlayer.prepareAsync()
    }

    // Функция для паузы музыки
    fun pauseMusic() {
        mediaPlayer.pause()
    }

    // Функция для перелистывания музыки
    fun playPreviousSong() {
        val currentIndex = songs.indexOf(songs.last())
        val previousSong = songs[currentIndex - 1]
        playMusic(previousSong)
    }

    // Функция для перелистывания музыки
    fun playNextSong() {
        val currentIndex = songs.indexOf(songs.last())
        val nextSong = songs[currentIndex + 1]
        playMusic(nextSong)
    }

    // Функция для отображения информации о треке
    fun showSongInfo(song: Song) {
        val songTitle = song.title
        val songArtist = song.artist
        val songAlbum = song.album
        val songDuration = song.duration
        // Display the information in a toast or a dialog
    }

    // Функция для получения списка песен с устройства
    fun getMusicFiles(): List<Song> {
        val musicFiles = mutableListOf<Song>()
        val filePath = Environment.getExternalStorageDirectory().absolutePath + "/Music"
        val file = File(filePath)
        val list = file.listFiles()
        for (i in list.indices) {
            val fileName = list[i].absolutePath
            val song = Song(fileName, file.getName(), "", 0, 0)
            musicFiles.add(song)
        }
        return musicFiles
    }

    // Функция для фильтрации списка песен
    fun filterSongs(filter: String, songs: List<Song>): List<Song> {
        val filteredSongs = mutableListOf<Song>()
        for (song in songs) {
            if (song.title.contains(filter, ignoreCase = true)) {
                filteredSongs.add(song)
            }
        }
        return filteredSongs
    }

    fun sortSongs(songs: List<Song>): List<Song> {
        val sortedSongs = songs.sortedWith(Comparator { song1, song2 ->
            song1.title.compareTo(song2.title)
        })
        return sortedSongs
    }
}



class SongAdapter(private val context: Context, private val songs: MutableList<Song>) : BaseAdapter() {
    private var inflater: LayoutInflater = LayoutInflater.from(context)
    private lateinit var songTitle: TextView

    override fun getCount(): Int {
        return songs.size
    }

    override fun getItem(position: Int): Any {
        return songs[position]
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val song = songs[position]
        val songTitle = song.title // Здесь можно получить название песни
        return songTitle
    }
}

class Song {
    var title: String = ""
    var artist: String = ""
    var album: String = ""
    var duration: Int = 0

    constructor(fileName: String, title: String, artist: String, album: String, duration: Int) {
        this.title = title
        this.artist = artist
        this.album = album
        this.duration = duration
    }
}

